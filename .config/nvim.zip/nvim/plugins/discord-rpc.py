import discord_rpc as rpc
import time

def main():
    def readyCallback(current_user):
        print('Our user: {}'.format(current_user))

    def disconnectedCallback(codeno, codemsg):
        print("Disconnected from Discord rich presence RPC. Code {}: {}".format(codeno, codemsg))

    def errorCallback(errno, errmsg):
        print("An error occurred! Error {}: {}".format(errno, errmsg))

    callbacks = {
        'ready': readyCallback,
        'disconnected': disconnectedCallback,
        'error': errorCallback
    }
    
    print("initializing...")
    rpc.initialize('972860229014392832', callbacks=callbacks, log=False)
    start = time.time()
 
    while True:
        print("loop")
        rpc.update_presence(
            **{
                'details': '闇の力を得たものは、いつかその身を滅ぼすのだ(?)',
                'start_timestamp': start,
                'large_image_key': 'vim'
              }
        )

        rpc.update_connection()
        time.sleep(1)
        rpc.run_callbacks()

main()
